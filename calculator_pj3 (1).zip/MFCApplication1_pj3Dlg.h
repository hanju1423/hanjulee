﻿
// MFCApplication1_pj3Dlg.h: 헤더 파일
//

#pragma once


// CMFCApplication1pj3Dlg 대화 상자
class CMFCApplication1pj3Dlg : public CDialogEx
{
// 생성입니다.
public:
	CMFCApplication1pj3Dlg(CWnd* pParent = nullptr);	// 표준 생성자입니다.

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_MFCAPPLICATION1_PJ3_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 지원입니다.


// 구현입니다.
protected:
	HICON m_hIcon;

	// 생성된 메시지 맵 함수
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CString Edit_result;

	bool Flag;
	int opera;
	float number0, number1, number2,number3;
	CString str1, str2;
	afx_msg void OnBnClickedB0();
	afx_msg void OnBnClickedB1();
	afx_msg void OnBnClickedB2();
	afx_msg void OnBnClickedB3();
	afx_msg void OnBnClickedB4();
	afx_msg void OnBnClickedB5();
	afx_msg void OnBnClickedB6();
	afx_msg void OnBnClickedB7();
	afx_msg void OnBnClickedB8();
	afx_msg void OnBnClickedB9();
	afx_msg void OnBnClickedBPlus();
	afx_msg void OnBnClickedBSub();
	afx_msg void OnBnClickedBMul();
	afx_msg void OnBnClickedBEqual();
	afx_msg void OnBnClickedBDiv();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnEnChangeEdit4();
	afx_msg void OnBnClickedButtonEqual();
	afx_msg void OnBnClickedBPoint();
	afx_msg void OnEnChangeEdit1();
};
